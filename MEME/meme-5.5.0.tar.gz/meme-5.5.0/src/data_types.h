#ifndef DATA_TYPES_H
#define DATA_TYPES_H

// Variables in the SAMPLE struct
typedef double Z_T;
//typedef float Z_T;

//typedef double LCB_T;
typedef float LCB_T;

//typedef double WEIGHTS_T;
typedef float WEIGHTS_T;

#endif

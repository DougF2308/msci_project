#ifndef GLAM2_COLUMN_SAMPLE_H
#define GLAM2_COLUMN_SAMPLE_H

#include "glam2_glam2.h"

void column_sample(glam2_aln *aln, data *d, const double temperature);

#endif

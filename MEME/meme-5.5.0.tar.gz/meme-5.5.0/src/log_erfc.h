#ifndef LOG_ERFC_H
#define LOG_ERFC_H
double log_erfc(double x);
#endif
